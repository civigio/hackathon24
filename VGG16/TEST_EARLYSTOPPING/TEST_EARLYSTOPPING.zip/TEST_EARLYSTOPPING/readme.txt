RUN 1: medium dataset, val-loss, 100 epochs, patience 3 --> stop at 6 and restore 3
RUN 2: medium dataset, val-loss, 100 epochs, patience 5 --> stop at 10 and restore 5
RUN 3: medium dataset, val-loss, 100 epochs, patience 10 --> stop at 19 and restore 9
RUN 4: small dataset, val-loss, 200 epochs, patience 50 --> stop at 60 and restore 10